# print_package.py

def print_message(message):
    """
    Print the given message to the console.

    Args:
    - message (str): The message to be printed.
    """
    print(message)
